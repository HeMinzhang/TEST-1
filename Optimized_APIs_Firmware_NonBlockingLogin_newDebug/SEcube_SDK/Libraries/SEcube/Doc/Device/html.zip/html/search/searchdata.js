var indexSectionsWithContent =
{
  0: "abcdfhiklmnrstuwy",
  1: "abs",
  2: "cs",
  3: "bfhls",
  4: "abcdiklmnrstuwy",
  5: "s",
  6: "s",
  7: "achks"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enumvalues",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerator",
  7: "Modules"
};

