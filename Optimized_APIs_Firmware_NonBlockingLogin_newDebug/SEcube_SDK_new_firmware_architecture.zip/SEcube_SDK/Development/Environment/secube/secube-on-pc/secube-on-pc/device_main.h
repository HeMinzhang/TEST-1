#pragma once

void device_init();
void device_loop();
