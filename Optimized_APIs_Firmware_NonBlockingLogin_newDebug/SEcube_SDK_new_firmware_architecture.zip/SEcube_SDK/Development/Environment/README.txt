
1. Clone secube repo here
    git clone https://USERNAME@bitbucket.org/nicifer/secube
    
2. Start Eclipse and set its workspace to the "ws" directory