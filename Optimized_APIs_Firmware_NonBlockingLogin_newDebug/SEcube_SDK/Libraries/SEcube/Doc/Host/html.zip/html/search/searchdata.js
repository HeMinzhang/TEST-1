var indexSectionsWithContent =
{
  0: "abchiklmnrs",
  1: "bs",
  2: "cls",
  3: "bls",
  4: "imnr",
  5: "s",
  6: "s",
  7: "achks"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enumvalues",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerator",
  7: "Modules"
};

